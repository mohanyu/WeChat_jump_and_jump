<!-- Copyright 2015 The Chromium Authors. All rights reserved.
     Use of this source code is governed by a BSD-style license that can be
     found in the LICENSE file.
-->
devil
=====

devil is a library used by the Chromium developers to interact with Android
devices. It currently supports SDK level 16 and above.

😈

Contributing
============

Please see the [contributor's guide](https://github.com/catapult-project/catapult/blob/master/CONTRIBUTING.md).

